INSTRUCCIONES:

1. Extraer contenido del .zip en la carpeta "cstrike" (usualmente se encuentra en "C:\Program Files(x86)Valve\cstrike").
2. Si pregunta si desea combinar las carpetas o sobreescribir archivos, elegir "S�".

-----

INSTRUCTIONS:

1.Extract all the zip content directly into "cstrike" folder - usually it's in "C:\Program Files(x86)\Valve\cstrike".
2. If asked if you wish to merge folders or overwrite files files choose "yes".